package ec.edu.pucem.facturacion.formulario;

import ec.edu.pucem.facturacion.modelo.Cliente;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class FrmListaClientes extends JFrame {

    private static final long serialVersionUID = 1L;
    private JTable table;
    private DefaultTableModel tableModel;
    private Cliente clienteSeleccionado;

    public FrmListaClientes(List<Cliente> clientes) {
        setTitle("Lista de Clientes");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 600, 400);
        getContentPane().setLayout(null);

        String[] columnNames = {"Cédula", "Nombres", "Apellidos", "Dirección", "Teléfono", "Email"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(10, 10, 560, 300);
        getContentPane().add(scrollPane);

        for (Cliente cliente : clientes) {
            Object[] row = {cliente.getCedula(), cliente.getNombres(), cliente.getApellidos(), cliente.getDireccion(), cliente.getTelefono(), cliente.getEmail()};
            tableModel.addRow(row);
        }

        JButton btnSeleccionar = new JButton("Seleccionar");
        btnSeleccionar.setBounds(10, 320, 150, 25);
        getContentPane().add(btnSeleccionar);

        btnSeleccionar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    String cedula = (String) tableModel.getValueAt(selectedRow, 0);
                    String nombres = (String) tableModel.getValueAt(selectedRow, 1);
                    String apellidos = (String) tableModel.getValueAt(selectedRow, 2);
                    String direccion = (String) tableModel.getValueAt(selectedRow, 3);
                    String telefono = (String) tableModel.getValueAt(selectedRow, 4);
                    String email = (String) tableModel.getValueAt(selectedRow, 5);
                    clienteSeleccionado = new Cliente(cedula, nombres, apellidos, direccion, telefono, email);
                    dispose(); // Cerrar el formulario después de seleccionar
                } else {
                    JOptionPane.showMessageDialog(null, "Debe seleccionar un cliente.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

    public Cliente getClienteSeleccionado() {
        return clienteSeleccionado;
    }
}

