package ec.edu.pucem.facturacion.formulario;

import ec.edu.pucem.facturacion.modelo.Producto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class FrmListaProductos extends JFrame {

    private static final long serialVersionUID = 1L;
    private JTable table;
    private DefaultTableModel tableModel;
    private Producto productoSeleccionado;

    public FrmListaProductos(List<Producto> productos) {
        setTitle("Lista de Productos");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 600, 400);
        getContentPane().setLayout(null);

        String[] columnNames = {"Código", "Nombre", "Precio", "Stock"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(10, 10, 560, 300);
        getContentPane().add(scrollPane);

        for (Producto producto : productos) {
            Object[] row = {producto.getCodigo(), producto.getNombre(), producto.getPrecio(), producto.getStock()};
            tableModel.addRow(row);
        }

        JButton btnSeleccionar = new JButton("Seleccionar");
        btnSeleccionar.setBounds(10, 320, 150, 25);
        getContentPane().add(btnSeleccionar);

        btnSeleccionar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    String codigo = (String) tableModel.getValueAt(selectedRow, 0);
                    String nombre = (String) tableModel.getValueAt(selectedRow, 1);
                    double precio = (double) tableModel.getValueAt(selectedRow, 2);
                    int stock = (int) tableModel.getValueAt(selectedRow, 3);
                    productoSeleccionado = new Producto(codigo, nombre, precio, stock);
                    dispose();
                }
            }
        });
    }

    public Producto getProductoSeleccionado() {
        return productoSeleccionado;
    }
}
