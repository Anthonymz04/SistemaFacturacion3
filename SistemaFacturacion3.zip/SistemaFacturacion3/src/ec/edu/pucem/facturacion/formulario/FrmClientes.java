package ec.edu.pucem.facturacion.formulario;

import ec.edu.pucem.facturacion.modelo.Cliente;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class FrmClientes extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtCedula;
    private JTextField txtNombres;
    private JTextField txtApellidos;
    private JTextField txtDireccion;
    private JTextField txtTelefono;
    private JTextField txtEmail;
    private JTable table;
    private DefaultTableModel tableModel;
    private List<Cliente> clientes;
    private FrmFacturar frmFacturar;

    public FrmClientes(FrmFacturar frmFacturar) {
        this.frmFacturar = frmFacturar;
        clientes = new ArrayList<>();
        setTitle("Clientes");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 600, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblCedula = new JLabel("Cédula");
        lblCedula.setBounds(10, 10, 100, 20);
        contentPane.add(lblCedula);

        txtCedula = new JTextField();
        txtCedula.setBounds(120, 10, 200, 20);
        contentPane.add(txtCedula);
        txtCedula.setColumns(10);

        JLabel lblNombres = new JLabel("Nombres");
        lblNombres.setBounds(10, 40, 100, 20);
        contentPane.add(lblNombres);

        txtNombres = new JTextField();
        txtNombres.setBounds(120, 40, 200, 20);
        contentPane.add(txtNombres);
        txtNombres.setColumns(10);

        JLabel lblApellidos = new JLabel("Apellidos");
        lblApellidos.setBounds(10, 70, 100, 20);
        contentPane.add(lblApellidos);

        txtApellidos = new JTextField();
        txtApellidos.setBounds(120, 70, 200, 20);
        contentPane.add(txtApellidos);
        txtApellidos.setColumns(10);

        JLabel lblDireccion = new JLabel("Dirección");
        lblDireccion.setBounds(10, 100, 100, 20);
        contentPane.add(lblDireccion);

        txtDireccion = new JTextField();
        txtDireccion.setBounds(120, 100, 200, 20);
        contentPane.add(txtDireccion);
        txtDireccion.setColumns(10);

        JLabel lblTelefono = new JLabel("Teléfono");
        lblTelefono.setBounds(10, 130, 100, 20);
        contentPane.add(lblTelefono);

        txtTelefono = new JTextField();
        txtTelefono.setBounds(120, 130, 200, 20);
        contentPane.add(txtTelefono);
        txtTelefono.setColumns(10);

        JLabel lblEmail = new JLabel("Email");
        lblEmail.setBounds(10, 160, 100, 20);
        contentPane.add(lblEmail);

        txtEmail = new JTextField();
        txtEmail.setBounds(120, 160, 200, 20);
        contentPane.add(txtEmail);
        txtEmail.setColumns(10);

        JButton btnNuevo = new JButton("Nuevo");
        btnNuevo.setBounds(10, 200, 90, 25);
        contentPane.add(btnNuevo);

        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.setBounds(110, 200, 90, 25);
        contentPane.add(btnGuardar);

        JButton btnCancelar = new JButton("Cancelar");
        btnCancelar.setBounds(210, 200, 90, 25);
        contentPane.add(btnCancelar);

        String[] columnNames = {"Cédula", "Nombres", "Apellidos", "Dirección", "Teléfono", "Email"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(10, 240, 560, 200);
        contentPane.add(scrollPane);

        btnGuardar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String cedula = txtCedula.getText();
                String nombres = txtNombres.getText();
                String apellidos = txtApellidos.getText();
                String direccion = txtDireccion.getText();
                String telefono = txtTelefono.getText();
                String email = txtEmail.getText();

                if (cedula.isEmpty() || nombres.isEmpty() || apellidos.isEmpty() || direccion.isEmpty() || telefono.isEmpty() || email.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Cliente cliente = new Cliente(cedula, nombres, apellidos, direccion, telefono, email);
                clientes.add(cliente);

                Object[] row = {cedula, nombres, apellidos, direccion, telefono, email};
                tableModel.addRow(row);

                // Agregar cliente al formulario de facturación
                frmFacturar.agregarCliente(cliente);

                clearFields();
            }
        });

        btnCancelar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                clearFields();
            }
        });

        btnNuevo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                clearFields();
            }
            /*el parámetro e proporciona acceso a la información esencial sobre el evento 
             * de acción que desencadenó la llamada al método. Este objeto ActionEvent 
             * permite identificar qué acción específica ocurrió y tomar las acciones 
             * correspondientes en función de esa información.
             */
        });
    }

    private void clearFields() {
        txtCedula.setText("");
        txtNombres.setText("");
        txtApellidos.setText("");
        txtDireccion.setText("");
        txtTelefono.setText("");
        txtEmail.setText("");
    }
}

