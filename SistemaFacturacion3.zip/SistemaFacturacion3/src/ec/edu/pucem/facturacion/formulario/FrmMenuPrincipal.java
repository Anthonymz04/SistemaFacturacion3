package ec.edu.pucem.facturacion.formulario;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FrmMenuPrincipal extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private FrmClientes frmClientes;
    private FrmProductos frmProductos;
    private FrmFacturar frmFacturar;

    public FrmMenuPrincipal() {
        setTitle("Sistema de Facturacion Electronica");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 562, 433);

        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        JMenu mnArchivo = new JMenu("Archivo");
        menuBar.add(mnArchivo);

        JMenuItem mntmSalir = new JMenuItem("Salir");
        mntmSalir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        mnArchivo.add(mntmSalir);

        JMenu mnClientes = new JMenu("Clientes");
        menuBar.add(mnClientes);

        JMenuItem mntmCrearNuevoCliente = new JMenuItem("Nuevo Cliente");
        mntmCrearNuevoCliente.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (frmClientes == null || !frmClientes.isShowing()) {
                    frmClientes = new FrmClientes(frmFacturar);
                    frmClientes.setVisible(true);
                }
            }
        });
        mnClientes.add(mntmCrearNuevoCliente);

        JMenu mnProductos = new JMenu("Productos");
        menuBar.add(mnProductos);

        JMenuItem mntmCrearNuevoProducto = new JMenuItem("Nuevo Producto");
        mntmCrearNuevoProducto.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (frmProductos == null || !frmProductos.isShowing()) {
                    frmProductos = new FrmProductos(frmFacturar);
                    frmProductos.setVisible(true);
                }
            }
        });
        mnProductos.add(mntmCrearNuevoProducto);

        JMenu mnFacturas = new JMenu("Facturas");
        menuBar.add(mnFacturas);

        JMenuItem mntmFacturar = new JMenuItem("Facturar");
        mntmFacturar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (frmFacturar == null || !frmFacturar.isShowing()) {
                    frmFacturar = new FrmFacturar();
                    frmFacturar.setVisible(true);
                }
            }
        });
        mnFacturas.add(mntmFacturar);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
    }
}
