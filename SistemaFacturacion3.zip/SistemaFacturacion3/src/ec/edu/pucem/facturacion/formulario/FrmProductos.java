package ec.edu.pucem.facturacion.formulario;

import ec.edu.pucem.facturacion.modelo.Producto;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class FrmProductos extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtCodigo;
    private JTextField txtNombre;
    private JTextField txtPrecio;
    private JTextField txtStock;
    private JTable table;
    private DefaultTableModel tableModel;
    private List<Producto> productos;
    private FrmFacturar frmFacturar;

    public FrmProductos(FrmFacturar frmFacturar) {
        this.frmFacturar = frmFacturar;
        productos = new ArrayList<>();
        setTitle("Productos");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 600, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblCodigo = new JLabel("Código");
        lblCodigo.setBounds(10, 10, 100, 20);
        contentPane.add(lblCodigo);

        txtCodigo = new JTextField();
        txtCodigo.setBounds(120, 10, 200, 20);
        contentPane.add(txtCodigo);
        txtCodigo.setColumns(10);

        JLabel lblNombre = new JLabel("Nombre");
        lblNombre.setBounds(10, 40, 100, 20);
        contentPane.add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(120, 40, 200, 20);
        contentPane.add(txtNombre);
        txtNombre.setColumns(10);

        JLabel lblPrecio = new JLabel("Precio");
        lblPrecio.setBounds(10, 70, 100, 20);
        contentPane.add(lblPrecio);

        txtPrecio = new JTextField();
        txtPrecio.setBounds(120, 70, 200, 20);
        contentPane.add(txtPrecio);
        txtPrecio.setColumns(10);

        JLabel lblStock = new JLabel("Stock");
        lblStock.setBounds(10, 100, 100, 20);
        contentPane.add(lblStock);

        txtStock = new JTextField();
        txtStock.setBounds(120, 100, 200, 20);
        contentPane.add(txtStock);
        txtStock.setColumns(10);

        JButton btnNuevo = new JButton("Nuevo");
        btnNuevo.setBounds(10, 140, 90, 25);
        contentPane.add(btnNuevo);

        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.setBounds(110, 140, 90, 25);
        contentPane.add(btnGuardar);

        JButton btnCancelar = new JButton("Cancelar");
        btnCancelar.setBounds(210, 140, 90, 25);
        contentPane.add(btnCancelar);

        String[] columnNames = {"Código", "Nombre", "Precio", "Stock"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(10, 180, 560, 250);
        contentPane.add(scrollPane);

        btnGuardar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String codigo = txtCodigo.getText();
                String nombre = txtNombre.getText();
                String precio = txtPrecio.getText();
                String stock = txtStock.getText();

                if (codigo.isEmpty() || nombre.isEmpty() || precio.isEmpty() || stock.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                Producto producto = new Producto(codigo, nombre, Double.parseDouble(precio), Integer.parseInt(stock));
                productos.add(producto);

                Object[] row = {codigo, nombre, precio, stock};
                tableModel.addRow(row);

                // Agregar producto al formulario de facturación
                frmFacturar.agregarProducto(producto);

                clearFields();
            }
        });

        btnCancelar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                clearFields();
            }
        });

        btnNuevo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                clearFields();
            }
        });
    }

    private void clearFields() {
        txtCodigo.setText("");
        txtNombre.setText("");
        txtPrecio.setText("");
        txtStock.setText("");
    }
}

