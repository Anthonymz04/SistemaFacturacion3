package ec.edu.pucem.facturacion.formulario;

import ec.edu.pucem.facturacion.modelo.Cliente;
import ec.edu.pucem.facturacion.modelo.Producto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class FrmFacturar extends JFrame {

    private List<Producto> productosFactura;
    private DefaultTableModel tableModel;
    private JComboBox<Cliente> cmbClientes;
    private Cliente clienteSeleccionado;

    public FrmFacturar() {
        productosFactura = new ArrayList<>();

        setTitle("Facturación");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        getContentPane().add(panel);
        panel.setLayout(null);

        JLabel lblCliente = new JLabel("Cliente:");
        lblCliente.setBounds(20, 20, 80, 20);
        panel.add(lblCliente);

        cmbClientes = new JComboBox<>();
        cmbClientes.setBounds(100, 20, 200, 20);
        panel.add(cmbClientes);

        JLabel lblProductos = new JLabel("Productos:");
        lblProductos.setBounds(20, 50, 80, 20);
        panel.add(lblProductos);

        JButton btnAgregarProducto = new JButton("Agregar Producto");
        btnAgregarProducto.setBounds(20, 80, 150, 25);
        panel.add(btnAgregarProducto);

        String[] columnNames = {"Código", "Nombre", "Precio", "Cantidad", "Total"};
        tableModel = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 110, 760, 400);
        panel.add(scrollPane);

        JButton btnCalcularTotal = new JButton("Calcular Total");
        btnCalcularTotal.setBounds(600, 520, 150, 30);
        panel.add(btnCalcularTotal);

        

        btnAgregarProducto.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                abrirFormularioListaProductos();
            }
        });

        btnCalcularTotal.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                calcularTotal();
            }
        });

        //obtener la lista de productos y clientes al iniciar
        cargarClientes();
        cargarProductos();
    }

    private void abrirFormularioListaClientes() {
        FrmClientes frmClientes = new FrmClientes(this);
        frmClientes.setVisible(true);
    }

    private void abrirFormularioListaProductos() {
        FrmProductos frmProductos = new FrmProductos(this);
        frmProductos.setVisible(true);
    }

    public void agregarCliente(Cliente cliente) {
        cmbClientes.addItem(cliente);
    }

    public void agregarProducto(Producto producto) {
        Object[] row = {producto.getCodigo(), producto.getNombre(), producto.getPrecio(), 1, producto.getPrecio()};
        tableModel.addRow(row);
        productosFactura.add(producto);
    }

    private void calcularTotal() {
        double subtotal = 0.0;
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            double totalProducto = (double) tableModel.getValueAt(i, 4);
            subtotal += totalProducto;
        }

        double iva = subtotal * 0.12;
        double total = subtotal + iva;

        JOptionPane.showMessageDialog(null, String.format("Subtotal: $%.2f\nIVA (12%%): $%.2f\nTotal: $%.2f", subtotal, iva, total), "Total de la Factura", JOptionPane.INFORMATION_MESSAGE);
    }

    private void cargarClientes() {

        List<Cliente> clientes = new ArrayList<>();
        
        for (Cliente cliente : clientes) {
            cmbClientes.addItem(cliente);
        }
    }

    private void cargarProductos() {
        List<Producto> productos = new ArrayList<>();
        
    }

    
}
