package ec.edu.pucem.facturacion;

import ec.edu.pucem.facturacion.formulario.FrmMenuPrincipal;

public class Main {
    public static void main(String[] args) {
        FrmMenuPrincipal frame = new FrmMenuPrincipal();
        frame.setVisible(true);
    }
}
